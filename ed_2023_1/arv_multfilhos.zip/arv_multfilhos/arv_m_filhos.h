/*
 * UFMT - Universidade Federal de Mato Grosso
 * Campus Universitario do Araguaia
 * Bacharelado em Ciencia da Computacao
 * 
 * Disciplina de ED I
 * Prof. Ivairton
 * Aluna: Fernanda Lima de Souza
 * 
 * Implementacao da estrutura ARVORE BINARIA
 * Arquivo de cabeçalho ARVORE.H
*/


#include <stdio.h>
#include <stdlib.h>

#ifndef __ARV_M_FILHOS_H__
#define __ARV_M_FILHOS_H__

#define T 3  // define a capacidade do no da arvore

//definicao da estrutura nó
struct est_arv_m  {
    int dados[T];
    struct est_arv_m *filhos[T+1];
    int cont;
    
};
typedef struct est_arv_m  tipo_arv_m_f;

//prototipo das funcoes
tipo_arv_m_f *alocaNoArvMF(int);
void insereArvMF(tipo_arv_m_f **, int);

int buscaValorArvMF(tipo_arv_m_f *, int);
void percursoPreOrdemArvMF(tipo_arv_m_f *);
void percursoPosOrdemArvMF(tipo_arv_m_f *);
void percursoOrdemArvMF(tipo_arv_m_f *);

int alturaArvMF(tipo_arv_m_f *);
void imprimeNivelArvMF(tipo_arv_m_f*, int);


int contabilizaValoresArvMF(tipo_arv_m_f*);
int contabilizaFolhasArvMF(tipo_arv_m_f*);
int contabilizaNosArvMF(tipo_arv_m_f *);

int maiorValorArvMF(tipo_arv_m_f*);
int menorValorArvMF(tipo_arv_m_f*);

int ehFolha(tipo_arv_m_f*);
void removeArvMF(tipo_arv_m_f **, int);



#endif //__ARV_M_FILHOS_H__