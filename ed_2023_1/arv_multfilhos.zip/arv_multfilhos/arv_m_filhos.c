#include "arv_m_filhos.h"

tipo_arv_m_f *alocaNoArvMF(int vl){
    tipo_arv_m_f *novo_no;
    novo_no = (tipo_arv_m_f*)malloc(sizeof(tipo_arv_m_f));
    int i;
    novo_no->cont = 0;
    for (i=0; i<T; i++){
        novo_no->filhos[i] = NULL;
    }
    novo_no->dados[novo_no->cont++]= vl;
    return novo_no;

}
void insereArvMF(tipo_arv_m_f **arv, int vl){
    int i;

    if ((*arv) == NULL){
        (*arv) = alocaNoArvMF(vl);
    }else{
        if((*arv)->cont <T){
            i=(*arv)->cont-1;
            while((i > 0) && (vl<(*arv)->dados[i])){
                (*arv)->dados[i+1] = (*arv)->dados[i];
                i --;
            }
            (*arv)->dados[i+1]=vl;
            (*arv)->cont++;

        }else{
            i = 0;
            while( (i<T) && (vl < (*arv)->dados[i]) ){
                i++;
            }
            insereArvMF(&(*arv)->filhos[i],vl);
        }
    }

}
int buscaValorArvMF(tipo_arv_m_f *arv, int vl){
    int i;
    if(arv!=NULL){ //verifica se o no nao e vazio
        i =0;
        while((arv->dados[i] < vl) && (i<T)){
            i++;
        }
        if((i<T)&& (arv->dados [i]==vl)){
            return 1;
        }else{
            return buscaValorArvMF(arv->filhos[i],vl);
        }
    }else{ // contradoaso no seja vazio, valor nao foi encontrado
        return 0;
    }
}


void percursoPreOrdemArvMF(tipo_arv_m_f *arv){
    int i;
    if(arv!= NULL){
         for(i=0; i<arv->cont; i++){
            printf("%d", arv->dados[i]);
        }
        for(i=0; i<= arv->cont; i++){
            percursoPreOrdemArvMF(arv->filhos[i]);
        }
    }
   
}
void percursoPosOrdemArvMF(tipo_arv_m_f *arv){
    int i;
    if(arv != NULL){
        for(i=0; i<= arv->cont; i++){
            percursoPosOrdemArvMF(arv->filhos[i]);
        }
        for(i=0; i<arv->cont; i++){
           printf("%d", arv->dados[i]);
        }
    }
}
void percursoOrdemArvMF(tipo_arv_m_f *arv){
    int i;
    if(arv != NULL){
        for(i=0; i< arv->cont; i++){
            percursoOrdemArvMF(arv->filhos[i]);
            printf("%d", arv->dados[i]);
        }
        percursoOrdemArvMF(arv->filhos[i]);
    }
}

int contabilizaValoresArvMF(tipo_arv_m_f*arv){
    int total, i;
    total=0;
    if(arv!= NULL){
        for(i=0; i<=arv->cont; i++)
            total += contabilizaValoresArvMF(arv->filhos[i]);
        total += arv->cont;
    }
    return total;
}

int contabilizaFolhasArvMF(tipo_arv_m_f*arv){
    int i, flag;

    if (arv != NULL) {
        flag = 0;
        for(i=0; i<=arv->cont; i++)
            flag += contabilizaValoresArvMF(arv->filhos[i]);
        if (flag == 0)
            return 1;
        else
            return flag;
    
    }
    return 0;
}

int contabilizaNosArvMF(tipo_arv_m_f *arv){
   int i, contador;
   if(arv == NULL){
        return 0;
   }else{
        contador = 0;
        for(i=0; i<=arv->cont; i++)
            contador += contabilizaNosArvMF(arv->filhos[i]);
        return contador + 1;
   }

}
int alturaArvMF(tipo_arv_m_f *arv){
    int i, maior, h_atual;
    if(arv == NULL){
        return -1;
    }else{
        maior =  alturaArvMF(arv->filhos[0]);
        for(i=0; i<=arv->cont; i++){
            h_atual = alturaArvMF(arv->filhos[i]);
            if(h_atual>maior)
            maior = h_atual;
        }
        return maior + 1;
   }
}
void imprimeNivelArvMF(tipo_arv_m_f*arv, int nivel){
    int i;
    if (arv != NULL){
        if (nivel == 0){
            printf("[");
            for(i=0; i<arv->cont; i++)
                printf(" %d ",(arv->dados[i]));
            printf("]");
        } else {
            for(i=0; i<=arv->cont; i++)
                imprimeNivelArvMF(arv->filhos[i], nivel-1);
        }
    }
}

int maiorValorArvMF(tipo_arv_m_f *arv){
    if(arv->filhos[arv->cont]==NULL){
        return arv->dados[arv->cont -1];
    }else{
        return maiorValorArvMF(arv->filhos[arv->cont]);
    }
}

int menorValorArvMF(tipo_arv_m_f*arv){
    
    if(arv != NULL){
        if(arv->filhos[0] == NULL){
            arv->dados[0];
        }else{
            return menorValorArvMF(arv->filhos[0]);
        }
    }
    return 0;
}

int ehFolha(tipo_arv_m_f*arv){
    int i, flag;
    flag = 1; //parte do principio que o no eh folha
    i = 0;

    do{
        if(arv->filhos[i] != NULL) //se tem filho, nao eh folha
            flag = 0;
    }while(i<=arv->cont);
    return flag;

    
}
void removeArvMF(tipo_arv_m_f **arv, int cont){

}